/*
 * This is an OpenSSL-compatible implementation of the RSA Data Security, Inc.
 * MD5 Message-Digest Algorithm (RFC 1321).
 *
 * Homepage:
 * http://openwall.info/wiki/people/solar/software/public-domain-source-code/md5
 *
 * Author:
 * Alexander Peslyak, better known as Solar Designer <solar at openwall.com>
 *
 * This software was written by Alexander Peslyak in 2001.  No copyright is
 * claimed, and the software is hereby placed in the public domain.
 * In case this attempt to disclaim copyright and place the software in the
 * public domain is deemed null and void, then the software is
 * Copyright (c) 2001 Alexander Peslyak and it is hereby released to the
 * general public under the following terms:
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted.
 *
 * There's ABSOLUTELY NO WARRANTY, express or implied.
 *
 * (This is a heavily cut-down "BSD license".)
 *
 * This differs from Colin Plumb's older public domain implementation in that
 * no exactly 32-bit integer data type is required (any 32-bit or wider
 * unsigned integer data type will do), there's no compile-time endianness
 * configuration, and the function prototypes match OpenSSL's.  No code from
 * Colin Plumb's implementation has been reused; this comment merely compares
 * the properties of the two independent implementations.
 *
 * The primary goals of this implementation are portability and ease of use.
 * It is meant to be fast, but not as fast as possible.  Some known
 * optimizations are not included to reduce source code size and avoid
 * compile-time configuration.
 */

#include <string.h>

#include "rhash.h"

/*
 * The basic MD5 functions.
 *
 * F and G are optimized compared to their RFC 1321 definitions for
 * architectures that lack an AND-NOT instruction, just like in Colin Plumb's
 * implementation.
 */
#define MD5_F(x, y, z)			((z) ^ ((x) & ((y) ^ (z))))
#define MD5_G(x, y, z)			((y) ^ ((z) & ((x) ^ (y))))
#define MD5_H(x, y, z)			(((x) ^ (y)) ^ (z))
#define MD5_H2(x, y, z)			((x) ^ ((y) ^ (z)))
#define MD5_I(x, y, z)			((y) ^ ((x) | ~(z)))

/*
 * The MD5 transformation for all four rounds.
 */
#define MD5_STEP(f, a, b, c, d, x, t, s) \
	(a) += f((b), (c), (d)) + (x) + (t); \
	(a) = (((a) << (s)) | (((a) & 0xffffffff) >> (32 - (s)))); \
	(a) += (b);

/*
 * MD5_SET reads 4 input bytes in little-endian byte order and stores them
 * in a properly aligned word in host byte order.
 *
 * The check for little-endian architectures that tolerate unaligned
 * memory accesses is just an optimization.  Nothing will break if it
 * doesn't work.
 */
#if defined(__i386__) || defined(__x86_64__) || defined(__vax__)
#define MD5_SET(n) \
	(*(MD5_u32plus *)&ptr[(n) * 4])
#define MD5_GET(n) \
	MD5_SET(n)
#else
#define MD5_SET(n) \
	(ctx->block[(n)] = \
	(MD5_u32plus)ptr[(n) * 4] | \
	((MD5_u32plus)ptr[(n) * 4 + 1] << 8) | \
	((MD5_u32plus)ptr[(n) * 4 + 2] << 16) | \
	((MD5_u32plus)ptr[(n) * 4 + 3] << 24))
#define MD5_GET(n) \
	(ctx->block[(n)])
#endif

/*
 * This processes one or more 64-byte data blocks, but does NOT update
 * the bit counters.  There are no alignment requirements.
 */
static const void *MD5_body(MD5_CTX *ctx, const void *data, unsigned long size)
{
	const unsigned char *ptr;
	MD5_u32plus a, b, c, d;
	MD5_u32plus saved_a, saved_b, saved_c, saved_d;

	ptr = (const unsigned char *)data;

	a = ctx->a;
	b = ctx->b;
	c = ctx->c;
	d = ctx->d;

	do {
		saved_a = a;
		saved_b = b;
		saved_c = c;
		saved_d = d;

/* Round 1 */
		MD5_STEP(MD5_F, a, b, c, d, MD5_SET(0), 0xd76aa478, 7)
		MD5_STEP(MD5_F, d, a, b, c, MD5_SET(1), 0xe8c7b756, 12)
		MD5_STEP(MD5_F, c, d, a, b, MD5_SET(2), 0x242070db, 17)
		MD5_STEP(MD5_F, b, c, d, a, MD5_SET(3), 0xc1bdceee, 22)
		MD5_STEP(MD5_F, a, b, c, d, MD5_SET(4), 0xf57c0faf, 7)
		MD5_STEP(MD5_F, d, a, b, c, MD5_SET(5), 0x4787c62a, 12)
		MD5_STEP(MD5_F, c, d, a, b, MD5_SET(6), 0xa8304613, 17)
		MD5_STEP(MD5_F, b, c, d, a, MD5_SET(7), 0xfd469501, 22)
		MD5_STEP(MD5_F, a, b, c, d, MD5_SET(8), 0x698098d8, 7)
		MD5_STEP(MD5_F, d, a, b, c, MD5_SET(9), 0x8b44f7af, 12)
		MD5_STEP(MD5_F, c, d, a, b, MD5_SET(10), 0xffff5bb1, 17)
		MD5_STEP(MD5_F, b, c, d, a, MD5_SET(11), 0x895cd7be, 22)
		MD5_STEP(MD5_F, a, b, c, d, MD5_SET(12), 0x6b901122, 7)
		MD5_STEP(MD5_F, d, a, b, c, MD5_SET(13), 0xfd987193, 12)
		MD5_STEP(MD5_F, c, d, a, b, MD5_SET(14), 0xa679438e, 17)
		MD5_STEP(MD5_F, b, c, d, a, MD5_SET(15), 0x49b40821, 22)

/* Round 2 */
		MD5_STEP(MD5_G, a, b, c, d, MD5_GET(1), 0xf61e2562, 5)
		MD5_STEP(MD5_G, d, a, b, c, MD5_GET(6), 0xc040b340, 9)
		MD5_STEP(MD5_G, c, d, a, b, MD5_GET(11), 0x265e5a51, 14)
		MD5_STEP(MD5_G, b, c, d, a, MD5_GET(0), 0xe9b6c7aa, 20)
		MD5_STEP(MD5_G, a, b, c, d, MD5_GET(5), 0xd62f105d, 5)
		MD5_STEP(MD5_G, d, a, b, c, MD5_GET(10), 0x02441453, 9)
		MD5_STEP(MD5_G, c, d, a, b, MD5_GET(15), 0xd8a1e681, 14)
		MD5_STEP(MD5_G, b, c, d, a, MD5_GET(4), 0xe7d3fbc8, 20)
		MD5_STEP(MD5_G, a, b, c, d, MD5_GET(9), 0x21e1cde6, 5)
		MD5_STEP(MD5_G, d, a, b, c, MD5_GET(14), 0xc33707d6, 9)
		MD5_STEP(MD5_G, c, d, a, b, MD5_GET(3), 0xf4d50d87, 14)
		MD5_STEP(MD5_G, b, c, d, a, MD5_GET(8), 0x455a14ed, 20)
		MD5_STEP(MD5_G, a, b, c, d, MD5_GET(13), 0xa9e3e905, 5)
		MD5_STEP(MD5_G, d, a, b, c, MD5_GET(2), 0xfcefa3f8, 9)
		MD5_STEP(MD5_G, c, d, a, b, MD5_GET(7), 0x676f02d9, 14)
		MD5_STEP(MD5_G, b, c, d, a, MD5_GET(12), 0x8d2a4c8a, 20)

/* Round 3 */
		MD5_STEP(MD5_H, a, b, c, d, MD5_GET(5), 0xfffa3942, 4)
		MD5_STEP(MD5_H2, d, a, b, c, MD5_GET(8), 0x8771f681, 11)
		MD5_STEP(MD5_H, c, d, a, b, MD5_GET(11), 0x6d9d6122, 16)
		MD5_STEP(MD5_H2, b, c, d, a, MD5_GET(14), 0xfde5380c, 23)
		MD5_STEP(MD5_H, a, b, c, d, MD5_GET(1), 0xa4beea44, 4)
		MD5_STEP(MD5_H2, d, a, b, c, MD5_GET(4), 0x4bdecfa9, 11)
		MD5_STEP(MD5_H, c, d, a, b, MD5_GET(7), 0xf6bb4b60, 16)
		MD5_STEP(MD5_H2, b, c, d, a, MD5_GET(10), 0xbebfbc70, 23)
		MD5_STEP(MD5_H, a, b, c, d, MD5_GET(13), 0x289b7ec6, 4)
		MD5_STEP(MD5_H2, d, a, b, c, MD5_GET(0), 0xeaa127fa, 11)
		MD5_STEP(MD5_H, c, d, a, b, MD5_GET(3), 0xd4ef3085, 16)
		MD5_STEP(MD5_H2, b, c, d, a, MD5_GET(6), 0x04881d05, 23)
		MD5_STEP(MD5_H, a, b, c, d, MD5_GET(9), 0xd9d4d039, 4)
		MD5_STEP(MD5_H2, d, a, b, c, MD5_GET(12), 0xe6db99e5, 11)
		MD5_STEP(MD5_H, c, d, a, b, MD5_GET(15), 0x1fa27cf8, 16)
		MD5_STEP(MD5_H2, b, c, d, a, MD5_GET(2), 0xc4ac5665, 23)

/* Round 4 */
		MD5_STEP(MD5_I, a, b, c, d, MD5_GET(0), 0xf4292244, 6)
		MD5_STEP(MD5_I, d, a, b, c, MD5_GET(7), 0x432aff97, 10)
		MD5_STEP(MD5_I, c, d, a, b, MD5_GET(14), 0xab9423a7, 15)
		MD5_STEP(MD5_I, b, c, d, a, MD5_GET(5), 0xfc93a039, 21)
		MD5_STEP(MD5_I, a, b, c, d, MD5_GET(12), 0x655b59c3, 6)
		MD5_STEP(MD5_I, d, a, b, c, MD5_GET(3), 0x8f0ccc92, 10)
		MD5_STEP(MD5_I, c, d, a, b, MD5_GET(10), 0xffeff47d, 15)
		MD5_STEP(MD5_I, b, c, d, a, MD5_GET(1), 0x85845dd1, 21)
		MD5_STEP(MD5_I, a, b, c, d, MD5_GET(8), 0x6fa87e4f, 6)
		MD5_STEP(MD5_I, d, a, b, c, MD5_GET(15), 0xfe2ce6e0, 10)
		MD5_STEP(MD5_I, c, d, a, b, MD5_GET(6), 0xa3014314, 15)
		MD5_STEP(MD5_I, b, c, d, a, MD5_GET(13), 0x4e0811a1, 21)
		MD5_STEP(MD5_I, a, b, c, d, MD5_GET(4), 0xf7537e82, 6)
		MD5_STEP(MD5_I, d, a, b, c, MD5_GET(11), 0xbd3af235, 10)
		MD5_STEP(MD5_I, c, d, a, b, MD5_GET(2), 0x2ad7d2bb, 15)
		MD5_STEP(MD5_I, b, c, d, a, MD5_GET(9), 0xeb86d391, 21)

		a += saved_a;
		b += saved_b;
		c += saved_c;
		d += saved_d;

		ptr += 64;
	} while (size -= 64);

	ctx->a = a;
	ctx->b = b;
	ctx->c = c;
	ctx->d = d;

	return ptr;
}

void MD5_Init(MD5_CTX *ctx)
{
	ctx->a = 0x67452301;
	ctx->b = 0xefcdab89;
	ctx->c = 0x98badcfe;
	ctx->d = 0x10325476;

	ctx->lo = 0;
	ctx->hi = 0;
}

void MD5_Update(MD5_CTX *ctx, const void *data, unsigned long size)
{
	MD5_u32plus saved_lo;
	unsigned long used, available;

	saved_lo = ctx->lo;
	if ((ctx->lo = (saved_lo + size) & 0x1fffffff) < saved_lo)
		ctx->hi++;
	ctx->hi += size >> 29;

	used = saved_lo & 0x3f;

	if (used) {
		available = 64 - used;

		if (size < available) {
			memcpy(&ctx->buffer[used], data, size);
			return;
		}

		memcpy(&ctx->buffer[used], data, available);
		data = (const unsigned char *)data + available;
		size -= available;
		MD5_body(ctx, ctx->buffer, 64);
	}

	if (size >= 64) {
		data = MD5_body(ctx, data, size & ~(unsigned long)0x3f);
		size &= 0x3f;
	}

	memcpy(ctx->buffer, data, size);
}

void MD5_Final(unsigned char *result, MD5_CTX *ctx)
{
	unsigned long used, available;

	used = ctx->lo & 0x3f;

	ctx->buffer[used++] = 0x80;

	available = 64 - used;

	if (available < 8) {
		memset(&ctx->buffer[used], 0, available);
		MD5_body(ctx, ctx->buffer, 64);
		used = 0;
		available = 64;
	}

	memset(&ctx->buffer[used], 0, available - 8);

	ctx->lo <<= 3;
	ctx->buffer[56] = ctx->lo;
	ctx->buffer[57] = ctx->lo >> 8;
	ctx->buffer[58] = ctx->lo >> 16;
	ctx->buffer[59] = ctx->lo >> 24;
	ctx->buffer[60] = ctx->hi;
	ctx->buffer[61] = ctx->hi >> 8;
	ctx->buffer[62] = ctx->hi >> 16;
	ctx->buffer[63] = ctx->hi >> 24;

	MD5_body(ctx, ctx->buffer, 64);

	result[0] = ctx->a;
	result[1] = ctx->a >> 8;
	result[2] = ctx->a >> 16;
	result[3] = ctx->a >> 24;
	result[4] = ctx->b;
	result[5] = ctx->b >> 8;
	result[6] = ctx->b >> 16;
	result[7] = ctx->b >> 24;
	result[8] = ctx->c;
	result[9] = ctx->c >> 8;
	result[10] = ctx->c >> 16;
	result[11] = ctx->c >> 24;
	result[12] = ctx->d;
	result[13] = ctx->d >> 8;
	result[14] = ctx->d >> 16;
	result[15] = ctx->d >> 24;

	memset(ctx, 0, sizeof(*ctx));
}

#ifdef MD5_BUILD_UTILITY

#include <stdio.h>

int main (int argc, char *argv[])
{
   /* For each command line argument in turn:
    ** filename          -- prints message digest and name of file
    */
   int i;
   MD5_CTX ctx;
   FILE* file;
   size_t numread;
   char buffer[16384];
   unsigned char result[16];

   for (i = 1; i < argc; i++)
   {
      MD5_Init(&ctx);
      file = fopen(argv[i], "rb");

      if (file)
      {
         do
         {
            numread = fread((void*)buffer, 1, sizeof(buffer), file);

            if (numread)
            {
               MD5_Update(&ctx,(void*)buffer, numread);
            }
         }
         while (numread);

         fclose(file);
         MD5_Final(result, &ctx);
         printf("%02x%02x%02x%02x%02x%02x%02x%02x"
			          "%02x%02x%02x%02x%02x%02x%02x%02x %s\n",
			          result[ 0 ], result[ 1 ], result[ 2 ], result[ 3 ],
                result[ 4 ], result[ 5 ], result[ 6 ], result[ 7 ],
                result[ 8 ], result[ 9 ], result[ 10 ], result[ 11 ],
                result[ 12 ], result[ 13 ], result[ 14 ], result[ 15 ],
                argv[i]);
      }
   }

   return 0;
}

#endif
