/* Copyright  (C) 2010-2020 The RetroArch team
 *
 * ---------------------------------------------------------------------------------------
 * The following license statement only applies to this file (chd_stream.c).
 * ---------------------------------------------------------------------------------------
 *
 * Permission is hereby granted, free of charge,
 * to any person obtaining a copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software,
 * and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

#include "chd_stream.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "../libchdr/include/libchdr/chd.h"
#include "../boolean.h"

#define SECTOR_RAW_SIZE 2352
#define SECTOR_SIZE 2048
#define SUBCODE_SIZE 96
#define TRACK_PAD 4

struct chdstream
{
   chd_file *chd;
   /* Loaded hunk */
   uint8_t *hunkmem;
   /* Byte offset where track data starts (after pregap) */
   uint64_t track_start;
   /* Byte offset where track data ends */
   uint64_t track_end;
   /* Byte offset of read cursor */
   uint64_t offset;
   /* Loaded hunk number */
   uint32_t hunknum;
   /* Size of frame taken from each hunk */
   unsigned long frame_size;
   /* Offset of data within frame */
   unsigned long frame_offset;
   /* Number of frames per hunk */
   unsigned long frames_per_hunk;
   /* First frame of track in chd */
   unsigned long track_frame;
   /* Should we swap bytes? */
   bool swab;
};

typedef struct metadata
{
   unsigned long frame_offset;
   unsigned long frames;
   unsigned long pad;
   unsigned long extra;
   unsigned long pregap;
   unsigned long postgap;
   unsigned long track;
   char type[64];
   char subtype[32];
   char pgtype[32];
   char pgsub[32];
} metadata_t;

static unsigned long padding_frames(unsigned long frames)
{
   return ((frames + TRACK_PAD - 1) & ~((unsigned long)TRACK_PAD - 1)) - frames;
}

static bool
chdstream_get_meta(chd_file *chd, unsigned long idx, metadata_t *md)
{
   char meta[256];
   uint32_t meta_size = 0;
   chd_error err;

   meta[0] = '\0';

   memset(md, 0, sizeof(*md));

   err = chd_get_metadata(chd, CDROM_TRACK_METADATA2_TAG, idx, meta,
         sizeof(meta), &meta_size, NULL, NULL);

   if (err == CHDERR_NONE)
   {
      sscanf(meta, "TRACK:%lu TYPE:%s SUBTYPE:%s FRAMES:%lu PREGAP:%lu PGTYPE:%s PGSUB:%s POSTGAP:%lu",
            &md->track, md->type,
            md->subtype, &md->frames, &md->pregap,
            md->pgtype, md->pgsub,
            &md->postgap);
      md->extra = padding_frames(md->frames);
      return true;
   }

   err = chd_get_metadata(chd, CDROM_TRACK_METADATA_TAG, idx, meta,
         sizeof(meta), &meta_size, NULL, NULL);

   if (err == CHDERR_NONE)
   {
      sscanf(meta, "TRACK:%lu TYPE:%s SUBTYPE:%s FRAMES:%lu", &md->track, md->type,
             md->subtype, &md->frames);
      md->extra = padding_frames(md->frames);
      return true;
   }

   err = chd_get_metadata(chd, GDROM_TRACK_METADATA_TAG, idx, meta,
         sizeof(meta), &meta_size, NULL, NULL);

   if (err == CHDERR_NONE)
   {
      sscanf(meta, "TRACK:%lu TYPE:%s SUBTYPE:%s FRAMES:%lu PAD:%lu PREGAP:%lu PGTYPE:%s PGSUB:%s POSTGAP:%lu", &md->track, md->type,
             md->subtype, &md->frames, &md->pad, &md->pregap, md->pgtype,
             md->pgsub, &md->postgap);
      md->extra = padding_frames(md->frames);
      return true;
   }

   err = chd_get_metadata(chd, DVD_METADATA_TAG, idx, meta,
         sizeof(meta), &meta_size, NULL, NULL);

   if (err == CHDERR_NONE)
   {
      md->track = 1;
      strcpy(md->type, "DVD");
      return true;
   }

   return false;
}

static bool
chdstream_find_track_number(chd_file *fd, unsigned long track, metadata_t *meta)
{
   uint32_t i;
   unsigned long frame_offset = 0;

   for (i = 0; true; ++i)
   {
      if (!chdstream_get_meta(fd, i, meta))
         return false;

      if (track == meta->track)
      {
         meta->frame_offset = frame_offset;
         return true;
      }

      frame_offset += meta->frames + meta->extra;
   }
}

static bool
chdstream_find_special_track(chd_file *fd, long track, metadata_t *meta)
{
   uint32_t i;
   metadata_t iter;
   unsigned long largest_track = 0;
   unsigned long largest_size = 0;

   for (i = 1; true; ++i)
   {
      if (!chdstream_find_track_number(fd, i, &iter))
      {
         if (track == CHDSTREAM_TRACK_LAST && i > 1)
            return chdstream_find_track_number(fd, i - 1, meta);

         if (track == CHDSTREAM_TRACK_PRIMARY && largest_track != 0)
            return chdstream_find_track_number(fd, largest_track, meta);

         return false;
      }

      switch (track)
      {
         case CHDSTREAM_TRACK_FIRST_DATA:
            if (strcmp(iter.type, "AUDIO"))
            {
               *meta = iter;
               return true;
            }
            break;
         case CHDSTREAM_TRACK_PRIMARY:
            if (strcmp(iter.type, "AUDIO") && iter.frames > largest_size)
            {
               largest_size  = iter.frames;
               largest_track = iter.track;
            }
            break;
         default:
            break;
      }
   }
}

static bool
chdstream_find_track(chd_file *fd, long track, metadata_t *meta)
{
   if (track < 0)
      return chdstream_find_special_track(fd, track, meta);
   return chdstream_find_track_number(fd, (unsigned long)track, meta);
}

static chdstream_t *chdstream_open_common(chd_file *chd, long track)
{
   metadata_t meta;
   unsigned long pregap         = 0;
   uint8_t *hunkmem        = NULL;
   const chd_header *hd    = NULL;
   chdstream_t *stream     = NULL;

   if (!chdstream_find_track(chd, track, &meta))
      goto error;

   stream                  = (chdstream_t*)malloc(sizeof(*stream));
   if (!stream)
      goto error;

   stream->chd             = NULL;
   stream->swab            = false;
   stream->frame_size      = 0;
   stream->frame_offset    = 0;
   stream->frames_per_hunk = 0;
   stream->track_frame     = 0;
   stream->track_start     = 0;
   stream->track_end       = 0;
   stream->offset          = 0;
   stream->hunkmem         = NULL;
   stream->hunknum         = (uint32_t)-1;

   hd                      = chd_get_header(chd);
   hunkmem                 = (uint8_t*)malloc(hd->hunkbytes);
   if (!hunkmem)
      goto error;

   stream->hunkmem         = hunkmem;

   if (strcmp(meta.type, "MODE1_RAW") == 0)
      stream->frame_size   = SECTOR_RAW_SIZE;
   else if (strcmp(meta.type, "MODE2_RAW") == 0)
      stream->frame_size   = SECTOR_RAW_SIZE;
   else if (strcmp(meta.type, "MODE1") == 0)
      stream->frame_size   = SECTOR_SIZE;
   else if (strcmp(meta.type, "AUDIO") == 0)
   {
      stream->frame_size   = SECTOR_RAW_SIZE;
      stream->swab         = true;
   }
   else if (strcmp(meta.type, "DVD") == 0)
   {
      stream->frame_size   = hd->unitbytes;
      meta.frames          = hd->totalhunks;
   }
   else
      stream->frame_size   = hd->unitbytes;

   /* Only include pregap data if it was in the track file */
   if (meta.pgtype[0] != 'V')
      pregap               = meta.pregap;

   stream->chd             = chd;
   stream->frames_per_hunk = hd->hunkbytes / hd->unitbytes;
   stream->track_frame     = meta.frame_offset;
   stream->track_start     = (uint64_t)pregap * stream->frame_size;
   stream->track_end       = stream->track_start +
                             (uint64_t)meta.frames * stream->frame_size;

   return stream;

error:
   chdstream_close(stream);

   if (chd)
      chd_close(chd);

   return NULL;
}

chdstream_t *chdstream_open(const char *path, long track)
{
   chd_file *chd = NULL;
   chd_error err = chd_open(path, CHD_OPEN_READ, NULL, &chd);

   if (err != CHDERR_NONE)
      return NULL;

   return chdstream_open_common(chd, track);
}

chdstream_t *chdstream_open_core_file(core_file *core, long track)
{
   chd_file *chd = NULL;
   chd_error err = chd_open_core_file(core, CHD_OPEN_READ, NULL, &chd);

   if (err != CHDERR_NONE)
      return NULL;

   return chdstream_open_common(chd, track);
}

chdstream_t *chdstream_open_core_file_callbacks(const core_file_callbacks *callbacks, const void *user_data, long track)
{
   chd_file *chd = NULL;
   chd_error err = chd_open_core_file_callbacks(callbacks, user_data, CHD_OPEN_READ, NULL, &chd);

   if (err != CHDERR_NONE)
      return NULL;

   return chdstream_open_common(chd, track);
}

void chdstream_close(chdstream_t *stream)
{
   if (!stream)
      return;

   if (stream->hunkmem)
      free(stream->hunkmem);
   if (stream->chd)
      chd_close(stream->chd);
   free(stream);
}

static bool
chdstream_load_hunk(chdstream_t *stream, uint32_t hunknum)
{
   if (hunknum == stream->hunknum)
      return true;

   if (chd_read(stream->chd, hunknum, stream->hunkmem) != CHDERR_NONE)
      return false;

   if (stream->swab)
   {
      uint32_t i;
      uint32_t count = chd_get_header(stream->chd)->hunkbytes;
      uint8_t *array = stream->hunkmem;
      for (i = 0; i < count; i += 2)
      {
         const uint8_t temp = array[i + 0];
         array[i + 0] = array[i + 1];
         array[i + 1] = temp;
      }
   }

   stream->hunknum = hunknum;
   return true;
}

size_t chdstream_read(chdstream_t *stream, void *data, size_t bytes)
{
   uint64_t end;
   size_t data_offset   = 0;
   const chd_header *hd = chd_get_header(stream->chd);
   uint8_t         *out = (uint8_t*)data;

   if (stream->track_end - stream->offset < bytes)
      bytes             = (size_t)(stream->track_end - stream->offset);

   end                  = stream->offset + bytes;

   while (stream->offset < end)
   {
      unsigned long frame_offset = (unsigned long)(stream->offset % stream->frame_size);
      unsigned long amount       = stream->frame_size - frame_offset;

      if (amount > end - stream->offset)
         amount = (unsigned long)(end - stream->offset);

      /* In pregap */
      if (stream->offset < stream->track_start)
         memset(out + data_offset, 0, amount);
      else
      {
         uint64_t chd_frame   = stream->track_frame +
            (stream->offset - stream->track_start) / stream->frame_size;
         uint64_t hunk        = chd_frame / stream->frames_per_hunk;
         uint64_t hunk_offset = (chd_frame % stream->frames_per_hunk)
            * hd->unitbytes;

         if (hunk > UINT32_MAX)
            return (size_t)-1;

         if (!chdstream_load_hunk(stream, (unsigned long)hunk))
            return (size_t)-1;

         memcpy(out + data_offset,
                stream->hunkmem + frame_offset
                + hunk_offset + stream->frame_offset, amount);
      }

      data_offset    += amount;
      stream->offset += amount;
   }

   return bytes;
}

int chdstream_getc(chdstream_t *stream)
{
   char c = 0;

   if (chdstream_read(stream, &c, sizeof(c) != sizeof(c)))
      return EOF;

   return c;
}

char *chdstream_gets(chdstream_t *stream, char *s, size_t len)
{
   int c;
   size_t _len = 0;
   while (_len < len && (c = chdstream_getc(stream)) != EOF)
      s[_len++] = (char)c;
   if (_len < len)
      s[_len]   = '\0';
   return s;
}

uint64_t chdstream_tell(chdstream_t *stream)
{
   return stream->offset;
}

void chdstream_rewind(chdstream_t *stream)
{
   stream->offset = 0;
}

int chdstream_seek(chdstream_t *stream, int64_t offset, int whence)
{
   uint64_t new_offset;

   switch (whence)
   {
      case SEEK_SET:
         if (offset < 0)
            return -1;
         new_offset = (uint64_t)offset;
         break;
      case SEEK_CUR:
         if (offset < 0 && (uint64_t)-offset > stream->offset)
            return -1;
         if (offset > 0 && (uint64_t)offset > UINT64_MAX - stream->offset)
            return -1;
         new_offset = stream->offset + (uint64_t)offset;
         break;
      case SEEK_END:
         if (offset < 0 && (uint64_t)-offset > stream->track_end)
            return -1;
         if (offset > 0 && (uint64_t)offset > UINT64_MAX - stream->track_end)
            return -1;
         new_offset = stream->track_end + (uint64_t)offset;
         break;
      default:
         return -1;
   }

   if (new_offset > stream->track_end)
      new_offset = stream->track_end;

   stream->offset = new_offset;
   return 0;
}

uint64_t chdstream_get_size(chdstream_t *stream)
{
   return stream->track_end - stream->track_start;
}

unsigned long chdstream_get_track_start(chdstream_t *stream)
{
   uint32_t i;
   metadata_t meta;
   unsigned long frame_offset = 0;

   for (i = 0; chdstream_get_meta(stream->chd, i, &meta); ++i)
   {
      if (stream->track_frame == frame_offset)
         return meta.pregap * stream->frame_size;

      frame_offset += meta.frames + meta.extra;
   }

   return 0;
}

unsigned long chdstream_get_frame_size(chdstream_t *stream)
{
   return stream->frame_size;
}

unsigned long chdstream_get_first_track_sector(chdstream_t* stream)
{
   uint32_t i;
   metadata_t meta;
   unsigned long frame_offset = 0;
   unsigned long sector_offset = 0;

   for (i = 0; chdstream_get_meta(stream->chd, i, &meta); ++i)
   {
      if (stream->track_frame == frame_offset)
         return sector_offset;

      sector_offset += meta.frames;
      frame_offset += meta.frames + meta.extra;
   }

   return 0;
}
